#########################################################################################################
#                                                                                                       #
#                          CS 87 A, Python Programming                                                  #
#                      This code is written by Rahisul Haque                                            #
#                           e-mail: rahisul@icloud.com                                                  #
#                                                                                                       #
#                                                                                                       #
#                                                                                                       #
#########################################################################################################


max = 0
min = 0
usr_input = 0 
while (usr_input != -1):
	usr_input = int(input("Please enter a grade:"))
	if (usr_input > 0):
		if usr_input >= max and usr_input >=min :
			min = usr_input
			max = usr_input
		elif usr_input < max and usr_input > min:
			min = usr_input
		else :
			min = usr_input
	elif usr_input < 0 and usr_input != -1:
		print "Invalid entry!"
print "The Max is ", max
print "and the Min is ", min